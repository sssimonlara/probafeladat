import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DataProcessing {
    public static final int CHANNELS = 32;
    public static final int WINDOW_SIZE = 3;
    private static volatile boolean pauseProcessing = false;
    private static volatile boolean stopProcessing = false;

    public static List<String> convertingInput(String inputFileName) {
        List<String> convertedData = new ArrayList<>();

        try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(inputFileName))) {
            int channelNumber = 1;

            StringBuilder[] Datas = new StringBuilder[CHANNELS];
            for (int i = 0; i < Datas.length; i++) {
                Datas[i] = new StringBuilder();
            }

            byte[] buffer = new byte[2];
            while (dataInputStream.read(buffer) != -1) {
                short pattern = (short) ((buffer[1] << 8) | (buffer[0] & 0xFF));
                Datas[channelNumber - 1].append(pattern).append(" ");

                channelNumber++;

                if (channelNumber > CHANNELS) {
                    channelNumber = 1;
                }
            }

            for (StringBuilder patterns : Datas) {
                convertedData.add(patterns.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return convertedData;
    }

    public static void pauseProcessing() {
        pauseProcessing = true;
    }

    public static void stopProcessing() {
        stopProcessing = true;
    }

    public static void creatingChannels(List<String> lines) {
        ExecutorService executorService = Executors.newFixedThreadPool(CHANNELS);

        try {
            for (int i = 0; i < lines.size(); i++) {
                if (stopProcessing) {
                    executorService.shutdownNow();
                    return;
                }

                if (pauseProcessing) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    i--;
                    continue;
                }

                final String[] numbers = lines.get(i).split(" ");
                final int lineNumber = i + 1;
                executorService.submit(() -> {
                    String outputFileName = "eeg_channel_" + lineNumber + ".csv";

                    int[] numArr = Arrays.stream(numbers).mapToInt(Integer::parseInt).toArray();

                    double[] averages = new double[numArr.length - WINDOW_SIZE + 1];

                    for (int b = 0; b <= numArr.length - WINDOW_SIZE; b++) {
                        int sum = 0;
                        for (int a = b; a < b + WINDOW_SIZE; a++) {
                            sum += numArr[a];
                        }
                        averages[b] = (double) sum / WINDOW_SIZE;
                    }

                    StringBuilder formattedNumbers = new StringBuilder();
                    for (int index = 0; index < numbers.length - WINDOW_SIZE + 1; index++) {
                        formattedNumbers.append(numbers[index]).append(",").append(averages[index]).append("\n");
                    }
                    formattedNumbers.deleteCharAt(formattedNumbers.length() - 1);

                    try (PrintWriter writer = new PrintWriter(new FileWriter(outputFileName))) {
                        writer.write(formattedNumbers.toString());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            }
        } finally {
            executorService.shutdown();
        }
    }
}