import javax.swing.*;
import java.io.File;

public class Main {
    private UI ui;
    private String inputFile = "";
    private volatile boolean processingInProgress = false;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main main = new Main();
            main.initialize();
        });
    }

    public void initialize() {
        ui = new UI();

        ui.addChooseFileListener(e -> chooseFile());
        ui.addStartListener(e -> startProcessing());
        ui.addPauseListener(e -> pauseProcessing());
        ui.addStopListener(e -> stopProcessing());
    }

    private void chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            inputFile = selectedFile.getAbsolutePath();
            ui.setStatus("File selected " + inputFile);
        }
    }

    private void startProcessing() {
        if (!inputFile.isEmpty() && !processingInProgress) {
            processingInProgress = true;
            ui.disableButtons();
            ui.setStatus("Processing data...");
            try {
                DataProcessing.creatingChannels(DataProcessing.convertingInput(inputFile));
                ui.setStatus("Data processing completed.");
            } finally {
                processingInProgress = false;
                ui.enableButtons();
            }
        } else {
            ui.setStatus("No input file selected or processing already in progress.");
        }
    }

    private void pauseProcessing() {
        if (processingInProgress) {
            DataProcessing.pauseProcessing();
            ui.setStatus("Processing paused.");
        } else {
            ui.setStatus("No processing in progress.");
        }
    }
    private void stopProcessing() {
        if (processingInProgress) {
            DataProcessing.stopProcessing();
            ui.setStatus("Processing stopped.");
        } else {
            ui.setStatus("No processing in progress.");
        }
    }
}