import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class UI {
    private final JLabel statusLabel;
    private final JButton chooseFileButton;
    private final JButton startButton;
    private final JButton pauseButton;
    private final JButton stopButton;

    public UI() {
        JFrame frame = new JFrame("Data Processing Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 200);

        statusLabel = new JLabel("Status: ");
        chooseFileButton = createButton("Choose Input File",new Color(3, 146, 207));
        startButton = createButton("Start",new Color(123, 192, 67));
        stopButton = createButton("Stop",new Color(238, 64, 53));
        pauseButton = createButton("Pause",new Color(243, 119, 54));

        JPanel panel = new JPanel();
        panel.add(statusLabel);
        panel.add(chooseFileButton);
        panel.add(startButton);
        panel.add(pauseButton);
        panel.add(stopButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    public void setStatus(String status) {
        statusLabel.setText("Status: " + status);
    }

    public void addChooseFileListener(ActionListener listener) {
        chooseFileButton.addActionListener(listener);
    }

    public void addStartListener(ActionListener listener) {
        startButton.addActionListener(listener);
    }

    public void addPauseListener(ActionListener listener) {
        pauseButton.addActionListener(listener);
    }

    public void addStopListener(ActionListener listener) {
        stopButton.addActionListener(listener);
    }

    private JButton createButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.BLACK);
        return button;
    }

    public void disableButtons() {
        chooseFileButton.setEnabled(false);
        startButton.setEnabled(false);
        pauseButton.setEnabled(true);
        stopButton.setEnabled(true);
    }

    public void enableButtons() {
        chooseFileButton.setEnabled(true);
        startButton.setEnabled(true);
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);
    }
}